<?php 
include "../controller/UsuarioController.php";

    if(!empty($_POST)){
        $usuario = new UsuarioController();
        $usuario->salvar($_POST);
    }

    if(!empty($_GET['id'])){
      $data = $usuario->buscar($_GET['id']);
  }
?>

<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <form action="UsuarioForm.php" method="post">
        <label>Nome</label><br>
        <input type="text" name="nome"/><br>
        <label>Telefone</label><br>
        <input type="text" name="telefone"/><br>

        <input type="submit" name="Salvar"/><br>
    
    
    </form>

	</body>
</html>